package com.example.ProjetoSpring.Controller;

import com.example.ProjetoSpring.Model.Cliente;
import com.example.ProjetoSpring.Model.Produto;
import com.example.ProjetoSpring.Repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping (value = "/apiProjetoProduto")
public class ProdutoController {

    @Autowired
    ProdutoRepository prdrepo;

    @GetMapping("/todosProdutos")
    public List<Produto> buscarTodos()
    {

        return prdrepo.findAll();

    }

    @PostMapping(value = "/inserirProduto")
    public void inserirProduto(@RequestBody Produto novo)
    {

        prdrepo.save(novo);

    }

    @DeleteMapping(value = "/removerProduto")
    public void removerProduto(@RequestBody Produto produto)
    {

        prdrepo.delete(produto);

    }

    @PutMapping(value = "/atualizarCliente")
    public void atualizarProduto (@RequestBody Produto produto)
    {

        prdrepo.save(produto);

    }

    @GetMapping(value = "/ProdutosPorCodigo/{codigo}")
    public Optional<Produto> listaPorCodigo (@PathVariable (value = "codigo") int codigo)
    {
        return prdrepo.findById(codigo);
    }

    @GetMapping(value = "/ProdutosPorDescricao/{descricao}")
    public List<Produto> listaPorDescricao (@PathVariable (value = "descricao") String descricao)
    {
        return prdrepo.findByDescricao(descricao);
    }

    @GetMapping(value = "/ProdutosPorMarca/{marca}")
    public List<Produto> listaPorMarca (@PathVariable (value = "marca") String marca)
    {
        return prdrepo.findByMarca(marca);
    }

    @GetMapping(value = "/ProdutosPorPreco/{preco}")
    public List<Produto> listaPorPreco (@PathVariable (value = "preco") Float preco)
    {
        return prdrepo.findByPreco(preco);
    }

    @GetMapping(value = "/ProdutosPorCodigoMaior/{codigo}")
    public List<Produto> listaProdutoPorCodigoMaior (@PathVariable (value = "codigo") int codigo)
    {
        return prdrepo.findByCodigoMaior(codigo);
    }

    @GetMapping(value = "/ProdutosPorInicialDescricao/{descricao}")
    public List<Produto> listaProdutoPorInicialDescricao (@PathVariable (value = "descricao") String descricao)
    {
        return prdrepo.findByInicialDescricao(descricao);
    }

    @GetMapping(value = "/ProdutosPorInicialMarca/{marca}")
    public List<Produto> listaProdutoPorInicialMarca (@PathVariable (value = "marca") String marca)
    {
        return prdrepo.findByInicialMarca(marca);
    }

    @GetMapping(value = "/ProdutosPorPrecoMaiorInformado/{preco}")
    public List<Produto> listaProdutoPorPrecoMaior (@PathVariable (value = "preco") float preco)
    {
        return prdrepo.findByPrecoMaior(preco);
    }

    @GetMapping(value = "/ProdutosPorPrecoMenorInformado/{preco}")
    public List<Produto> listaProdutoPorPrecoMenor (@PathVariable (value = "preco") float preco)
    {
        return prdrepo.findByPrecoMenor(preco);
    }

    @GetMapping(value = "/ProdutosPorDescricaoMarca/{descricao}/{marca}")
    public List<Produto> listaProdutoPorDescricaoMarca (@PathVariable (value = "descricao") String descricao, @PathVariable(value = "marca") String marca )
    {
        return prdrepo.findByDescricaoMarca(descricao, marca);
    }

    @GetMapping(value = "/ProdutosPorDescricaoPrecoMenor/{descricao}/{preco}")
    public List<Produto> listaProdutoPorDescricaoPrecoMenor (@PathVariable (value = "descricao") String descricao, @PathVariable(value = "preco") float preco)
    {
        return prdrepo.findByDescricaoPrecoMenor(descricao,preco);
    }







}

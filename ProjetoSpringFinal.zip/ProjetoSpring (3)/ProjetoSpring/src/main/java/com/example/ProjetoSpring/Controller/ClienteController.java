package com.example.ProjetoSpring.Controller;

import com.example.ProjetoSpring.Model.Cliente;
import com.example.ProjetoSpring.Model.Produto;
import com.example.ProjetoSpring.Repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping (value = "/apiProjetoCliente")
public class ClienteController {

    @Autowired
    ClienteRepository clrepo;

    @GetMapping ("/todosClientes")
    public List<Cliente> buscarTodos()
    {
        return clrepo.findAll();

    }

    @PostMapping("/inserirCliente")
    public void inserirCliente(@RequestBody Cliente novo)
    {
       clrepo.save(novo);

    }

    @DeleteMapping(value = "removerCliente")
    public void removerCliente(@RequestBody Cliente cliente)
    {

        clrepo.delete(cliente);

    }

    @PutMapping(value = "/atualizarCliente")
    public void atualizarCliente (@RequestBody Cliente cliente)
    {

        clrepo.save(cliente);

    }

    @GetMapping(value = "/ClientesPorCodigo/{codigo}")
    public Optional<Cliente> listaPorCodigo (@PathVariable (value = "codigo") int codigo)
    {
        return clrepo.findById(codigo);
    }

    @GetMapping(value = "/ClientesPorNome/{nome}")
    public List<Cliente> listaPorNome (@PathVariable (value = "nome") String nome)
    {
        return clrepo.findByNome(nome);
    }

    @GetMapping(value = "/ClientesPorEmail/{email}")
    public List<Cliente> listaPorEmail (@PathVariable (value = "email") String email)
    {
        return clrepo.findByEmail(email);
    }

    @GetMapping(value = "/ClientesPorCodigoMaior/{codigo}")
    public List<Cliente> listaClientePorCodigoMaior (@PathVariable (value = "codigo") int codigo)
    {
        return clrepo.findByCodigoMaior(codigo);
    }

    @GetMapping(value = "/ClientesPorInicialNome/{nome}")
    public List<Cliente> listaClientePorInicialNome (@PathVariable (value = "nome") String nome)
    {
        return clrepo.findByInicialNome(nome);
    }

    @GetMapping(value = "/ClientesPorInicialEmail/{email}")
    public List<Cliente> listaClientePorInicialEmail (@PathVariable (value = "email") String email)
    {
        return clrepo.findByInicialEmail(email);
    }

    @GetMapping(value = "/ClientesPorNomeEmail/{nome}/{email}")
    public List<Cliente> listaClientePorNomeEmail (@PathVariable (value = "nome") String nome, @PathVariable(value = "email") String email)
    {
        return clrepo.findByNomeEmail(nome,email);

    }


}

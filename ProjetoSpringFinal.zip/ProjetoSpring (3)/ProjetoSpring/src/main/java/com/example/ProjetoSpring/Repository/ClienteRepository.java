package com.example.ProjetoSpring.Repository;

import com.example.ProjetoSpring.Model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ClienteRepository extends JpaRepository <Cliente, Integer> {

    List<Cliente> findByNome(String nome);
    List<Cliente> findByEmail(String email);

    @Query (value = "select a from Cliente a where a.codigo > ?1")
    public List<Cliente> findByCodigoMaior(int codigo);

    @Query (value = "select a from Cliente a where a.nome like %?1%")
    public List<Cliente> findByInicialNome(String nome);

    @Query (value = "select a from Cliente a where a.email like %?1%")
    public List<Cliente> findByInicialEmail(String email);

    @Query(value = "select a from Cliente a where a.nome like %?1% and a.email like %?2%" )
    public List<Cliente> findByNomeEmail(String nome, String email);

}

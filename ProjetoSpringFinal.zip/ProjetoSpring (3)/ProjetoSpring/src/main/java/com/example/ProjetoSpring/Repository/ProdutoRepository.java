package com.example.ProjetoSpring.Repository;

import com.example.ProjetoSpring.Model.Cliente;
import com.example.ProjetoSpring.Model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {

    public List<Produto> findByDescricao(String descricao);
    public List<Produto> findByMarca(String marca);

    @Query(value = "select a from Produto a where a.codigo > ?1")
    public List<Produto> findByCodigoMaior(int codigo);

    public List<Produto> findByPreco(float preco);

    @Query(value = "select a from Produto a where a.descricao like %?1%")
    public List<Produto> findByInicialDescricao(String descricao);

    @Query(value = "select a from Produto a where a.marca like %?1%")
    public List<Produto> findByInicialMarca(String marca);

    @Query(value = "select a from Produto a where a.preco > ?1")
    public List<Produto> findByPrecoMaior(float preco);

    @Query(value = "select a from Produto a where a.preco < ?1")
    public List<Produto> findByPrecoMenor(float preco);

    @Query(value = "select a from Produto a where a.descricao like %?1% and a.marca like %?2%")
    public List <Produto> findByDescricaoMarca(String descricao, String marca);

    @Query (value = "select a from Produto a where a.descricao like %?1% and a.preco < ?2")
    public List<Produto> findByDescricaoPrecoMenor(String descricao, float preco);
}
